effect give @a[tag=voidtotem] minecraft:levitation 8 20
effect give @a[tag=voidtotem] minecraft:slow_falling 60
execute as @a[tag=voidtotem] run tag @s remove voidtotem