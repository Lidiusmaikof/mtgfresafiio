tag @s add voidtotem
effect give @s minecraft:instant_damage 1 28
tp ~ ~5 ~
schedule function voidtotem:effectgive 2t
