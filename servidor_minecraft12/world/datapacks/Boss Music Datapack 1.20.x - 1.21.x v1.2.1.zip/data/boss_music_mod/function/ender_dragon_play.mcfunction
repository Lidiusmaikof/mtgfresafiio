stopsound @s music
scoreboard players add @s boss_music_mod.ender_dragon 1
title @s[scores={boss_music_mod.ender_dragon=1}] actionbar [{"bold":true,"color":"light_purple","translate":"Now playing:"},{"bold":false,"color":"white","translate":"solunary -"},{"bold":false,"color":"white","italic":true,"translate":"\"The end at hand\""}]
scoreboard players set @s[scores={boss_music_mod.ender_dragon=277}] boss_music_mod.ender_dragon 1
playsound boss_music_mod:enderdragonboss record @s[scores={boss_music_mod.ender_dragon=1}] ~ ~ ~ 0.65