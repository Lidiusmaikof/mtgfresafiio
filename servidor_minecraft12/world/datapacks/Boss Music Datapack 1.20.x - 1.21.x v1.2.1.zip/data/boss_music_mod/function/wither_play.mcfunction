stopsound @s music
scoreboard players add @s boss_music_mod.music.wither 1
title @s[scores={boss_music_mod.music.wither=1}] actionbar [{"bold":true,"color":"light_purple","translate":"Now playing:"},{"bold":false,"color":"white","translate":"84tangelo -"},{"bold":false,"color":"white","italic":true,"translate":"\"The Wither\""}]
scoreboard players set @s[scores={boss_music_mod.music.wither=128}] boss_music_mod.music.wither 1
playsound boss_music_mod:witherboss record @s[scores={boss_music_mod.music.wither=1}] ~ ~ ~ 0.7