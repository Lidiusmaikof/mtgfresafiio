fill ^-10 ^-10 ^-10 ^10 ^10 ^10 create:windmill_bearing[facing=north]{QueueAssembly:true} replace create:mechanical_bearing[facing=north]
fill ^-10 ^-10 ^-10 ^10 ^10 ^10 create:windmill_bearing[facing=east]{QueueAssembly:true} replace create:mechanical_bearing[facing=east]
fill ^-10 ^-10 ^-10 ^10 ^10 ^10 create:windmill_bearing[facing=south]{QueueAssembly:true} replace create:mechanical_bearing[facing=south]
fill ^-10 ^-10 ^-10 ^10 ^10 ^10 create:windmill_bearing[facing=west]{QueueAssembly:true} replace create:mechanical_bearing[facing=west]
setblock ^ ^ ^-1 air
setblock ^ ^-1 ^-2 air
setblock ~ ~ ~ air
gamerule sendCommandFeedback true