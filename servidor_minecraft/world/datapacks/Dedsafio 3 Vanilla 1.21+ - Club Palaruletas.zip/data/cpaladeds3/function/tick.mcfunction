function cpaladeds3:animacion/main
execute as @a[scores={cpala.totem=1..}] run function cpaladeds3:totem